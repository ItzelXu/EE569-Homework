# EE569 Homework Assignment #6
# Date: Apr 25, 2020
# Name: Zhiwei Deng
# ID: 3669230452
# email: zhiweide@usc.edu
#
# Compiled on Anaconda3 in MacOS
# Keras + Numpy + GTX1080 + Sklear

Use Jupyter Notebook to open the PixelHop.ipynb file and then run it in the blocks. 
For similarity check, the file is python format(.py)

# Code Review
	If there is any issues about the compiling and variables, please feel free to contact me.
